
package logica;

public class Usuario extends Persona{
    
    

    public Usuario() {
    }

    public Usuario(String nombre, String nombreUsuario, String correo, String contraseña, Rol rol) {
        super(nombre, nombreUsuario, correo, contraseña, rol);
    }

    
    
}
