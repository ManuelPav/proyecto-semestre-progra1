
package logica;

public class Administrador extends Trabajadores {

    public Administrador() {
    }
    
    
}
