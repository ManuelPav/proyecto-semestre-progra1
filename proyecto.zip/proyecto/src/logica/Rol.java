
package logica;

public class Rol extends Entidad{

    public Rol() {
    }

    public Rol(String nombre, String descripcion) {
        super(nombre, descripcion);
    }
    
    
}
